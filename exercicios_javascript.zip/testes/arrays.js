let array = ['html', 'css', 'javascript'];

//adicionar conteudo ao final do array 
array.push('nodejs')
//adicionar conteudo no inicio do array
array.unshift('react')
//remover do fim
array.pop()
//remover do começo 
array.shift()
// pegar somente alguns elementos do array (index, elemntos)
console.log(array.slice(0, 2))
// remover 1 ou mais itens em qualer posiçao do array
array.splice(1, 1)
// encontrar a posçao de um elemento
console.log(array.indexOf('javascript'))
console.log(array)