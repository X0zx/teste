const phrase = 'ooi meu chapa';
const replace = phrase.replace('2','1')
const array = phrase.split(' ');
const join = array.join('___')
const includes = phrase.includes('meu')
const arrayContructor = new Array(10);
const lista = Array.from(phrase);
console.log(lista)
console.log(includes)
console.log(array)
console.log(join)
console.log(replace)